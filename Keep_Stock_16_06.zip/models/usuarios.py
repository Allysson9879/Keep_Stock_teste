from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Usuarios(CrudBase):
    table = "usuarios"
    primary_key = "id_usuario" 
    fields = [
        "nome",
        "email",
        "senha",
        "cpf",
        "telefone",
        "ativo",
        "criado_em"
    ]
 
    def __init__(self, nome, email, senha, cpf, telefone, ativo, criado_em, id=None, id_usuario=None, **kwargs):
        self.nome = nome
        self.email = email
        self.senha = senha
        self.cpf = cpf
        self.telefone = telefone
        self.ativo = ativo
        self.criado_em = criado_em
        self.db = Database.get_client() # Pega o cliente do Supabase
        self.id = id or id_usuario
        self.id_usuario = self.id
        self.db = database.conectar_supabase()  # Conecta o cliente do Supabase
 
    @classmethod
    def find_all(cls, order_by=None):
        if order_by is None:
            order_by = cls.primary_key
        supabase = conectar_supabase()
        response = supabase.table(cls.table).select("*").order(order_by).execute()
        return response.data

    @classmethod
    def find_by_id(cls, id):
        supabase = conectar_supabase()
        response = supabase.table(cls.table).select("*").eq(cls.primary_key, id).execute()
        return response.data[0] if response.data else None

    @classmethod
    def delete(cls, id):
        supabase = conectar_supabase()
        response = supabase.table(cls.table).delete().eq(cls.primary_key, id).execute()
        return response.data

    def insert(self):
        supabase = conectar_supabase()
        dados = {campo: getattr(self, campo) for campo in self.fields}
        response = supabase.table(self.table).insert(dados).execute()
        return response.data

    def update(self, id):
        supabase = conectar_supabase()
        dados = {campo: getattr(self, campo) for campo in self.fields}
        response = supabase.table(self.table).update(dados).eq(self.primary_key, id).execute()
        return response.data

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.required(self.email, "email"),
            Validator.required(self.senha, "senha"),
            Validator.required(self.cpf, "cpf"),
            Validator.required(self.telefone, "telefone"),
            Validator.required(self.ativo, "ativo"),
            Validator.required(self.criado_em, "criado_em"),
        ]
        return [erro for erro in erros if erro]
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        devolucao = cls.find_by_id(id)
        if not devolucao:
            raise ValueError("Usuário não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o usuário porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_usuario(cls, id_usuario):
        supabase = conectar_supabase()
        response = supabase.table("usuarios").select("*").eq(cls.primary_key, id_usuario).execute()
        
        if response.data:
            d = response.data[0]
            return cls(
                id=d.get('id_usuario'),
                nome=d.get('nome'),
                email=d.get('email'),
                senha=d.get('senha'),
                cpf=d.get('cpf'),
                telefone=d.get('telefone'),
                ativo=d.get('ativo'),
                criado_em=d.get('criado_em'),
            )
        return None
    
    def inserir_usuario(self):
        supabase = conectar_supabase()
        dados = {campo: getattr(self, campo) for campo in self.fields}
        response = supabase.table(self.table).insert(dados).execute()
        return response.data

 