from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Fornecedor(CrudBase):
    table = "fornecedor"
    fields = [
        "nome",
        "cnpj",
        "telefone",
        "email",
        "endereço",
        "prod_fornecedor"
    ]
 
    def __init__(self, nome, cnpj, telefone, email,
                 endereço, prod_fornecedor):
        self.nome = nome
        self.cnpj = cnpj
        self.telefone = telefone
        self.email = email
        self.endereço = endereço
        self.prod_fornecedor = prod_fornecedor
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.validar_cnpj(self.cnpj, "cnpj"),
            Validator.non_negative(self.telefone, "telefone"),
            Validator.validar_email(self.email, "email"),
            Validator.required(self.endereco, "endereco"),
            Validator.required(self.prod_fornecedor, "prod_fornecedor")
        ]
        return [erro for erro in erros if erro]
 
 
 
    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE fornecedor_id = %s",
                "SELECT COUNT(*) FROM lotes WHERE fornecedor_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()
 
    @classmethod
    def safe_delete(cls, id):
        fornecedor = cls.find_by_id(id)
        if not fornecedor:
            raise ValueError("fornecedor não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o fornecedor porque possui tabelas vinculadas.")
        cls.delete(id)
 