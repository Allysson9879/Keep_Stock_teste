from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Funcionario(CrudBase):
    table = "funcionario"
    fields = [
        "id_usuario",
        "cargo",
        "setor",
        "salario"
    ]
 
    def __init__(self, id_usuario, cargo, setor, salario):
        self.id_usuario = id_usuario
        self.cargo = cargo
        self.setor = setor
        self.salario = salario
 
    def validate(self):
        erros = [
            Validator.required(self.cargo, "cargo"),
            Validator.required(self.setor, "setor"),
            Validator.non_negative(self.salario, "salario")
        ]
        return [erro for erro in erros if erro]
 
    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE funcionario_id = %s",
                "SELECT COUNT(*) FROM pedido_movimentacao WHERE funcionario_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()
 
    @classmethod
    def safe_delete(cls, id):
        funcionario = cls.find_by_id(id)
        if not funcionario:
            raise ValueError("Funcionario não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o funcionario porque ele possui pedidos ou movimentações vinculadas.")
        cls.delete(id)
 