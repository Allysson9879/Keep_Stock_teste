from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from core.validator import Validator
from flask_cors import CORS
from supabase import create_client, Client
from models.produto import Produto
from models.clientes import Cliente
from models.fornecedores import Fornecedor
from models.pedidos import Pedido
from models.movimentacoes_estoque import Movimentacoes_estoque
from models.entrada_produtos import Entradas_produtos
from models.saidas_produtos import Saidas_produtos
from models.areas_estoque import Area
from core.database import conectar_supabase
from datetime import datetime
import requests
import urllib.parse
import os
from werkzeug.utils import secure_filename
from core.security import login_obrigatorio, gerar_hash_senha, verificar_senha

app = Flask(__name__)
CORS(app) # CORS serve para permitir a troca de informações entre o frontend e o backend

# CONFIGURAÇÕES - TOKENS E URLS
app.secret_key = '133829382937huu92uwnsjw2iqjka93uend9nsmiwnd2982ubnsk'  
INVERTEXTO_TOKEN = "25384|j9ZTOhnY61kbOHY59QagFaLy86QvrCeY"

SUPABASE_URL = "https://gysiqyxpmlxmlolqzaqs.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5c2lxeXhwbWx4bWxvbHF6YXFzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NDk2MDcwNiwiZXhwIjoyMDkwNTM2NzA2fQ.DRqq9majrxnIT8oUnhrY2qQFB-OG6V4yOfTSGg27lpQ" 

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)



def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

# Funções para extrair os dados dos formulários

def get_produto_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "fornecedor": request.form.get("fornecedor", "").strip(),
        "categoria": request.form.get("categoria", "").strip(),
        "unidade_medida": request.form.get("unidade_medida", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "fornecedor": request.form.get("fornecedor", "").strip(),
        "valor_unitario_venda": to_float(request.form.get("valor_unitario_venda")),
        "valor_unitario_custo": to_float(request.form.get("valor_unitario_custo")),
        "quantidade_atual": to_int(request.form.get("quantidade_atual")),
        "quantidade_minima": to_int(request.form.get("quantidade_minima")),
        "controlado": request.form.get("controlado")
    }

def get_cliente_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cpf_cnpj": request.form.get("cpf_cnpj", "").strip(),
        "telefone": request.form.get("telefone", "").strip(),
        "email": request.form.get("email", "").strip(),
        "codigo_postal": request.form.get("codigo_postal", "").strip()
    }
    
def get_fornecedor_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": request.form.get("telefone", "").strip(),
        "email": request.form.get("email", "").strip(),
        "cep": request.form.get("cep", "").strip(),
    }

def get_pedido_form():
    return {
        "id_cliente": to_int(request.form.get("id_cliente")),
        "data_pedido": request.form.get("data_pedido", "").strip(),
        "status_pedido": request.form.get("status_pedido", "").strip(),
        "data_prevista": request.form.get("data_prevista", "").strip()
    }

def get_movimentacao_form():
    return {
        "id_produto": to_int(request.form.get("id_produto")),
        "id_usuario": to_int(request.form.get("id_usuario")),
        "tipo_movimentacao": request.form.get("tipo_movimentacao", "").strip(),
        "quantidade": to_int(request.form.get("quantidade")),
        "data_hora": request.form.get("data_hora", "").strip()
    }

def get_area_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "area_rua": request.form.get("area_rua", "").strip(),
        "area_codigo": request.form.get("area_codigo", "").strip(),
        "distancia_entre_prat": request.form.get("distancia_entre_prat", "").strip(),
        "temperatura_max": to_int(request.form.get("temperatura_max")),
        "temperatura_min": to_int(request.form.get("temperatura_min"))
    }

def get_entrada_form():
    return {
        "id_produto": to_int(request.form.get("id_produto"), default=None),
        "quantidade": to_int(request.form.get("quantidade")),
        "data_entrada": request.form.get("data_entrada", "").strip() or datetime.now().isoformat(),
        "id_usuario": session.get("usuario_id")
    }

def get_saida_form():
    return {
        "id_produto": to_int(request.form.get("id_produto"), default=None),
        "quantidade": to_int(request.form.get("quantidade")),
        "tipo_saida": request.form.get("tipo_saida", "").strip(),
        "id_cliente": to_int(request.form.get("id_cliente"), default=None),
        "data_saida": request.form.get("data_saida", "").strip() or datetime.now().isoformat(),
        "id_usuario": session.get("usuario_id")
    }

# Básico

@app.route("/")
def index():
    return render_template("index.html")


# Cadastro e Login
 
@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    # Recebe os dados do JavaScript
    dados = request.get_json()
    
    print(f"Dados recebidos: {dados}")

    if not dados:
        return jsonify({"erro": "Dados não fornecidos"}), 400

    # Validações Básicas de Presença
    nome = dados.get('nome')
    email_cliente = dados.get('email', '').strip().lower()
    cpf_cliente = dados.get('cpf', '').strip()
    senha = dados.get('senha')

    erro_nome = Validator.required(nome, "Nome")
    if erro_nome:
        return jsonify({"erro": erro_nome}), 400

    if not Validator.validar_nome(dados):
        return jsonify({"erro": "O nome deve ter entre 1 e 120 caracteres."}), 400

    # Validação de E-mail 
    resultado_api_email = Validator.validar_email(email_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_email:
        return jsonify({"erro": "Falha ao conectar com o validador de e-mail."}), 500
    
    
    if not resultado_api_email.get("valid_format") or not resultado_api_email.get("valid_mx"):
        return jsonify({"erro": "E-mail informado é inválido ou não existe."}), 400

    # Validação de CPF 
    
    resultado_api_cpf = Validator.validar_cpf(cpf_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_cpf:
        return jsonify({"erro": "Falha técnica ao validar CPF. Tente novamente mais tarde."}), 500


    if not resultado_api_cpf.get("valid"):
        return jsonify({
            "erro": "CPF inválido.",
            "detalhes": "O número informado não passou na validação oficial."
        }), 400

    # Gravação no Supabase 
    try:
        novo_usuario = {
            "nome": nome,
            "email": email_cliente,
            "cpf": cpf_cliente,
            "senha": gerar_hash_senha(senha)
        }
        
        # Executa o insert no Supabase
        supabase.table("usuarios").insert(novo_usuario).execute()
        
        return jsonify({"mensagem": "Cadastro realizado com sucesso!"}), 201

    except Exception as e:
        print(f"Erro no Supabase: {e}")
        return jsonify({"erro": "Erro ao salvar no banco de dados. Verifique se o CPF ou E-mail já existem."}), 500

@app.route('/login', methods=['POST'])
def login():
    try:
        dados = request.get_json()
        email_login = dados.get('email').strip().lower()
        senha_login = dados.get('senha')

        resposta = supabase.table("usuarios") \
            .select("*") \
            .eq("email", email_login) \
            .execute()

        # Verifica se o usuário existe mesmo
        if not resposta.data:
            return jsonify({"erro": "E-mail não cadastrado."}), 404
        
        usuario = resposta.data[0]

        # Verifica se a senha coincide também (bcrypt)
        senha_salva = usuario.get('senha', '')
        if verificar_senha(senha_login, senha_salva):
            # cria sessão para uso em rotas template
            session['usuario_id'] = usuario.get('id_usuario')
            session['usuario_nome'] = usuario.get('nome')
            return jsonify({
                "mensagem": "Login realizado com sucesso!",
                "nome": usuario.get('nome')
            }), 200
        else:
            return jsonify({"erro": "E-mail ou senha incorretos."}), 401

    # Se houver erro
    except Exception as e:
        print(f"Erro interno no Login: {e}")
        return jsonify({"erro": "Erro interno no servidor."}), 500


@app.route('/login_page', methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        senha = request.form.get('senha', '')

        try:
            resposta = supabase.table("usuarios").select("*").eq("email", email).execute()
            if not resposta.data:
                flash('E-mail não cadastrado.', 'erro')
                return redirect(url_for('login_page'))

            usuario = resposta.data[0]
            if verificar_senha(senha, usuario.get('senha', '')):
                session['usuario_id'] = usuario.get('id_usuario')
                session['usuario_nome'] = usuario.get('nome')
                flash('Login realizado com sucesso!', 'sucesso')
                return redirect(url_for('produtos'))
            else:
                flash('E-mail ou senha incorretos.', 'erro')
                return redirect(url_for('login_page'))

        except Exception as e:
            print(f"Erro no login template: {e}")
            flash('Erro interno no servidor.', 'erro')
            return redirect(url_for('login_page'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('login_page'))

# --- ROTAS DE TELAS ---

# Produtos
@app.route("/produtos")
def produtos():
    fornecedores = supabase.table("fornecedores").select("*").execute().data
    return render_template("produtos.html", produtos=Produto.find_all(order_by="nome"), fornecedores=fornecedores)

# Lotes
@app.route("/lotes")
def lotes():
    return render_template("lotes.html", lotes=Lote.find_all(order_by="id_lote"))

# Clientes
@app.route("/clientes")
def clientes():
    return render_template("clientes.html" , clientes=Cliente.find_all(order_by="nome"))

# Fornecedoes
@app.route("/fornecedores")
def fornecedores():
    return render_template("fornecedores.html", fornecedores=Fornecedor.find_all(order_by="nome"))

# Pedidos
@app.route("/pedidos")
def pedidos():
    return render_template("pedidos.html", pedidos=Pedido.find_all(order_by="id_pedido"), clientes=Cliente.find_all(order_by="nome"))

# Movimentações
@app.route("/movimentacoes")
def movimentacoes():
    produtos = Produto.find_all(order_by="nome")
    clientes = Cliente.find_all(order_by="nome")
    entradas = Entradas_produtos.find_all(order_by="id_entrada")
    saidas = Saidas_produtos.find_all(order_by="id_saida")
    produtos_map = {p["id_produto"]: p["nome"] for p in produtos}
    clientes_map = {c["id_cliente"]: c["nome"] for c in clientes}
    return render_template(
        "movimentacoes.html",
        entradas=entradas,
        saidas=saidas,
        produtos=produtos,
        clientes=clientes,
        produtos_map=produtos_map,
        clientes_map=clientes_map,
    )

# Áreas
@app.route("/areas")
def areas():
    return render_template("areas.html" , areas=Area.find_all(order_by="id_area"))

# Conformidades
@app.route("/conformidades")
def conformidades():
    return render_template("conformidades.html")

# Configurações
@app.route("/configuracoes")
def configuracoes():
    return render_template("configuracoes.html")

# Relatórios
@app.route("/relatorios")
def relatorios():
    return render_template("relatorios.html")


# TABELAS E SUAS RESPECTIVAS TELAS NO FRONTEND

# -- Dashboard = Um pouco de tudo
# -- Produtos: produtos.html
# -- Clientes: clientes.html
# -- Fornecedores: fornecedores.html
# -- Pedidos e Pedido_Itens: pedidos.html
# -- Movimentações, Lotes, Entradas e Saídas: movimentacoes.html
# -- Áreas, Áreas_Controladas, Sensores, Temperaturas_Controladas: areas.html
# -- Devoluçãoes, Descartes e Inspeção_Estoque: conformidades.html
# -- Relatórios: relatorios.html
# -- Permissões, Notificações, Informações de usuário, Sensores, Alertas: configuracoes.html

# --- ROTAS DE CRUD POR TABELAS ---

# Produtos

@app.route("/produto/salvar", methods=["POST"])
def salvar_produto():
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    try:
        produto.inserir_produto()
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("produtos.html", produto=dados)

@app.route("/produto/atualizar/<int:id>", methods=["POST"])
def atualizar_produto(id):
    dados = get_produto_form()
    dados["id"] = id
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("produtos.html", produto=dados)

    try:
        if not Produto.find_by_id(id):
            flash("Produto não encontrado.", "erro")
            return redirect(url_for("produtos"))

        produto.update(id)
        flash("Produto atualizado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar produto: {e}", "erro")
        return render_template("produtos.html", produto=dados)

@app.route("/produto/excluir/<int:id>")
def excluir_produto(id):
    try:
        Produto.safe_delete(id)
        flash("Produto excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir produto: {e}", "erro")
    return redirect(url_for("produtos"))

@app.route("/cliente/salvar", methods=["POST"])
def salvar_cliente():
    dados = get_cliente_form()
    cliente = Cliente(**dados)
    erros = cliente.validate()
    try:
        cliente.inserir_cliente()
        flash("Cliente cadastrado com sucesso.", "sucesso")
        return redirect(url_for("clientes"))
    except Exception as e:
        flash(f"Erro ao cadastrar cliente: {e}", "erro")
        return render_template("clientes.html", cliente=dados)

@app.route("/cliente/atualizar/<int:id>", methods=["POST"])
def atualizar_cliente(id):
    dados = get_cliente_form()
    dados["id"] = id
    cliente = Cliente(**dados)
    erros = cliente.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("clientes.html", cliente=dados)

    try:
        if not Cliente.find_by_id(id):
            flash("Cliente não encontrado.", "erro")
            return redirect(url_for("clientes"))

        cliente.update(id)
        flash("Cliente atualizado com sucesso.", "sucesso")
        return redirect(url_for("clientes"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar cliente: {e}", "erro")
        return render_template("clientes.html", cliente=dados)

@app.route("/cliente/excluir/<int:id>")
def excluir_cliente(id):
    try:
        Cliente.safe_delete(id)
        flash("Cliente excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir cliente: {e}", "erro")
    return redirect(url_for("clientes"))

# Fornecedores

@app.route("/fornecedor/salvar", methods=["POST"])
def salvar_fornecedor():
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    try:
        fornecedor.inserir_fornecedor()
        flash("Fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("fornecedores"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return render_template("fornecedores.html", fornecedor=dados)

@app.route("/fornecedor/atualizar/<int:id>", methods=["POST"])
def atualizar_fornecedor(id):
    dados = get_fornecedor_form()
    dados["id"] = id
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("fornecedores.html", fornecedor=dados)

    try:
        if not Fornecedor.find_by_id(id):
            flash("Fornecedor não encontrado.", "erro")
            return redirect(url_for("fornecedores"))

        fornecedor.update(id)
        flash("Fornecedor atualizado com sucesso.", "sucesso")
        return redirect(url_for("fornecedores"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar fornecedor: {e}", "erro")
        return render_template("fornecedores.html", fornecedor=dados)

@app.route("/fornecedor/excluir/<int:id>")
def excluir_fornecedor(id):
    try:
        Fornecedor.safe_delete(id)
        flash("Fornecedor excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir fornecedor: {e}", "erro")
    return redirect(url_for("fornecedores"))

# Pedidos

@app.route("/pedido/salvar", methods=["POST"])
def salvar_pedido():
    dados = get_pedido_form()
    pedido = Pedido(**dados)
    erros = pedido.validate()

    try:
        pedido.insert()
        flash("Pedido cadastrado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        flash(f"Erro ao cadastrar pedido: {e}", "erro")
        return render_template("pedidos.html", pedido=dados)

@app.route("/pedido/atualizar/<int:id>", methods=["POST"])
def atualizar_pedido(id):
    dados = get_pedido_form()
    dados["id"] = id
    pedido = Pedido(**dados)
    erros = pedido.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("pedidos.html", pedido=dados)

    try:
        if not Pedido.find_by_id(id):
            flash("Pedido não encontrado.", "erro")
            return redirect(url_for("pedidos"))

        pedido.update(id)
        flash("Pedido atualizado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar pedido: {e}", "erro")
        return render_template("pedidos.html", pedido=dados)

@app.route("/pedido/excluir/<int:id>")
def excluir_pedido(id):
    try:
        Pedido.safe_delete(id)
        flash("Pedido excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir pedido: {e}", "erro")
    return redirect(url_for("pedidos"))

# Movimentações

@app.route("/movimentacao/salvar", methods=["POST"])
def salvar_movimentacao():
    dados = get_movimentacao_form()
    movimentacao = Movimentacoes_estoque(**dados)
    erros = movimentacao.validate()

    try:
        movimentacao.insert()
        flash("Movimentação cadastrada com sucesso.", "sucesso")
        return redirect(url_for("movimentacoes"))
    except Exception as e:
        flash(f"Erro ao cadastrar movimentação: {e}", "erro")
        return render_template("movimentacoes.html", movimentacao=dados)

@app.route("/movimentacao/atualizar/<int:id>", methods=["POST"])
def atualizar_movimentacao(id):
    dados = get_movimentacao_form()
    dados["id_movimentacoes_estoque"] = id
    movimentacao = Movimentacoes_estoque(**dados)
    erros = movimentacao.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("movimentacoes.html", movimentacao=dados)

    try:
        if not Movimentacoes_estoque.find_by_id(id):
            flash("Movimentação não encontrada.", "erro")
            return redirect(url_for("movimentacoes"))

        movimentacao.update(id)
        flash("Movimentação atualizada com sucesso.", "sucesso")
        return redirect(url_for("movimentacoes"))
    except Exception as e:
        dados["id_movimentacoes_estoque"] = id
        flash(f"Erro ao atualizar movimentação: {e}", "erro")
        return render_template("movimentacoes.html", movimentacao=dados)

@app.route("/movimentacao/excluir/<int:id>")
def excluir_movimentacao(id):
    try:
        Movimentacoes_estoque.safe_delete(id)
        flash("Movimentação excluída com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir movimentação: {e}", "erro")
    return redirect(url_for("movimentacoes"))

# Entradas de produtos

@app.route("/entrada/salvar", methods=["POST"])
def salvar_entrada():
    dados = get_entrada_form()
    entrada = Entradas_produtos(**dados)
    erros = entrada.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return redirect(url_for("movimentacoes"))

    try:
        entrada.insert()
        ajustar_estoque_produto(dados["id_produto"], dados["quantidade"])
        flash("Entrada registrada com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao registrar entrada: {e}", "erro")
    return redirect(url_for("movimentacoes"))

@app.route("/entrada/atualizar/<int:id>", methods=["POST"])
def atualizar_entrada(id):
    dados = get_entrada_form()
    entrada = Entradas_produtos(**dados)
    erros = entrada.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return redirect(url_for("movimentacoes"))

    try:
        antiga = Entradas_produtos.find_by_id(id)
        if not antiga:
            flash("Entrada não encontrada.", "erro")
            return redirect(url_for("movimentacoes"))

        # Reverte o efeito da entrada antiga e aplica o da nova
        ajustar_estoque_produto(antiga["id_produto"], -(antiga.get("quantidade") or 0))
        entrada.update(id)
        ajustar_estoque_produto(dados["id_produto"], dados["quantidade"])
        flash("Entrada atualizada com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao atualizar entrada: {e}", "erro")
    return redirect(url_for("movimentacoes"))

@app.route("/entrada/excluir/<int:id>")
def excluir_entrada(id):
    try:
        antiga = Entradas_produtos.find_by_id(id)
        if not antiga:
            flash("Entrada não encontrada.", "erro")
            return redirect(url_for("movimentacoes"))

        Entradas_produtos.delete(id)
        # Excluir uma entrada desfaz o que ela somou ao estoque
        ajustar_estoque_produto(antiga["id_produto"], -(antiga.get("quantidade") or 0))
        flash("Entrada excluída com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir entrada: {e}", "erro")
    return redirect(url_for("movimentacoes"))

# Saídas de produtos

@app.route("/saida/salvar", methods=["POST"])
def salvar_saida():
    dados = get_saida_form()
    saida = Saidas_produtos(**dados)
    erros = saida.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return redirect(url_for("movimentacoes"))

    # Bloqueia a saída se não houver estoque suficiente
    produto = Produto.find_by_id(dados["id_produto"])
    estoque = (produto.get("quantidade_atual") or 0) if produto else 0
    if dados["quantidade"] > estoque:
        flash(f"Estoque insuficiente para a saída. Disponível: {estoque}.", "erro")
        return redirect(url_for("movimentacoes"))

    try:
        saida.insert()
        ajustar_estoque_produto(dados["id_produto"], -dados["quantidade"])
        flash("Saída registrada com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao registrar saída: {e}", "erro")
    return redirect(url_for("movimentacoes"))

@app.route("/saida/atualizar/<int:id>", methods=["POST"])
def atualizar_saida(id):
    dados = get_saida_form()
    saida = Saidas_produtos(**dados)
    erros = saida.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return redirect(url_for("movimentacoes"))

    try:
        antiga = Saidas_produtos.find_by_id(id)
        if not antiga:
            flash("Saída não encontrada.", "erro")
            return redirect(url_for("movimentacoes"))

        # Estoque disponível considerando o retorno da saída antiga e a aplicação da nova
        produto = Produto.find_by_id(dados["id_produto"])
        estoque = (produto.get("quantidade_atual") or 0) if produto else 0
        if antiga["id_produto"] == dados["id_produto"]:
            estoque += (antiga.get("quantidade") or 0)
        if dados["quantidade"] > estoque:
            flash(f"Estoque insuficiente para a saída. Disponível: {estoque}.", "erro")
            return redirect(url_for("movimentacoes"))

        ajustar_estoque_produto(antiga["id_produto"], (antiga.get("quantidade") or 0))
        saida.update(id)
        ajustar_estoque_produto(dados["id_produto"], -dados["quantidade"])
        flash("Saída atualizada com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao atualizar saída: {e}", "erro")
    return redirect(url_for("movimentacoes"))

@app.route("/saida/excluir/<int:id>")
def excluir_saida(id):
    try:
        antiga = Saidas_produtos.find_by_id(id)
        if not antiga:
            flash("Saída não encontrada.", "erro")
            return redirect(url_for("movimentacoes"))

        Saidas_produtos.delete(id)
        # Excluir uma saída retorna o valor da saída ao estoque
        ajustar_estoque_produto(antiga["id_produto"], (antiga.get("quantidade") or 0))
        flash("Saída excluída com sucesso.", "sucesso")
    except Exception as e:
        flash(f"Erro ao excluir saída: {e}", "erro")
    return redirect(url_for("movimentacoes"))

# Para entradas e saídas de produtos

def ajustar_estoque_produto(id_produto, delta):
    # Soma o valor a quantidade_atual do produto
    if not id_produto or not delta:
        return
    produto = Produto.find_by_id(id_produto)
    if not produto:
        return
    atual = produto.get("quantidade_atual") or 0
    supabase.table("produtos").update({"quantidade_atual": atual + delta}).eq("id_produto", id_produto).execute()

# Áreas

@app.route("/area/salvar", methods=["POST"])
def salvar_area():
    dados = get_area_form()
    area = Area(**dados)
    erros = area.validate()
    try:
        area.insert()
        flash("Área de estoque cadastrada com sucesso.", "sucesso")
        return redirect(url_for("areas"))
    except Exception as e:
        flash(f"Erro ao cadastrar área: {e}", "erro")
        return render_template("areas.html", area=dados)

@app.route("/area/atualizar/<int:id>", methods=["POST"])
def atualizar_area(id):
    dados = get_area_form()
    dados["id_area"] = id
    area = Area(**dados)
    erros = area.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("areas.html", area=dados)

    try:
        if not Area.find_by_id(id):
            flash("Área do estoque não encontrada.", "erro")
            return redirect(url_for("areas"))

        area.update(id)
        flash("Área do estoque atualizada com sucesso.", "sucesso")
        return redirect(url_for("areas"))
    except Exception as e:
        dados["id_area"] = id
        flash(f"Erro ao atualizar área do estoque: {e}", "erro")
        return render_template("areas.html", area=dados)

@app.route("/area/excluir/<int:id>")
def excluir_area(id):
    try:
        Area.safe_delete(id)
        flash("Área do estoque excluída com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir área do estoque: {e}", "erro")
    return redirect(url_for("areas"))

# Conformidades
# A fazer

# Relatórios 
# A fazer

# Configurações
# A fazer

if __name__ == "__main__":
    app.run(debug=True)
